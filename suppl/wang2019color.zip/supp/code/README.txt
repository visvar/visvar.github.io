
Readme of our Program:

This is a JS implementation of our algorithm.
You can directly open "index.html" using Microsoft Edge, or set up a server and then visit this page through the server.
You can use Python to quickly set up a server:
  1. open windows command line
  2. use http.server module:
     python -m http.server
Until now, a single server has been established, and the default port is 8000.
You can visit Http://localhost:8000/ to visit the page.
