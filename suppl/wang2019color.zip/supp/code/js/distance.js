function no_sqrt_euclidean_metric(a, b)
{
    var dx = a.x-b.x, dy = a.y-b.y;
    return dx*dx + dy*dy;
}

function euclidean_metric(a, b)
{
    return Math.sqrt(no_sqrt_euclidean_metric(a, b));
}
