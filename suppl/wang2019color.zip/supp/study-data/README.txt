File information:
- There are three files including two experiment data files and one participant information file
  part1_data.csv:   contains the experiment data collected from part 1 of the lab study
  part2_data.csv:   contains the experiment data collected from part 2 of the lab study
  participants.csv: contains the information of the lab study participants

Attribute information:
- part1_data.csv:
  user_id:       a unique id for each participant
  counting:      the number of classes that each participant observed
  actual_number: actual number of classes
  time:          time taken by the participant to find out the number of classes
  error:         difference between the participant's count and the actual number
  trial:         index of the trial
- part2_data.csv:
  user_id:       a unique id for each participant
  choice:        record whether the participant's choice is consistent to our score; possible values are "consistent", "inconsistent", and "no preference"
  time:          time taken by the participant
  trial:         index of the trial
- participant.csv:
  user_id:       an unique id for each participant
  gender:        gender of the participant
  age:           age of the participant
