Greetings!

This folder contains:

- Images of prototypes from TagFlip’s design process
- A brief explanation of how we processed our tag data from Last.fm for use in TagFlip
- Histograms for responses to all 22 questions on recommendation aspects
- A video showing the operation of TagFlip, recorded from a phone