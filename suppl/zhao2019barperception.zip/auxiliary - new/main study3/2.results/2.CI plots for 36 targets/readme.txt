"Error in PR for 72 tasks.csv" file contains all the estimation error in PR for 72 tasks. 

Trial order is consistent with the order in "raw data for 72 tasks.csv"files.

