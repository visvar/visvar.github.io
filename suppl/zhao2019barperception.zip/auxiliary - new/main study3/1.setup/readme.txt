This file is the stimuli in study 3.

Below is the explantion for each feature:

"Index" 
encodes trial IDs, containing 9 training trials (-9 to -1), quality controls (from 1000 to 1004) and 72 experimental trials (from 0 to 71). 

"dataSource"
contains information for each bar component. 
	"name", "value" and the title and value of bar component 
	"ifTarget" denotes whether this bar is chosen as target.

"barScale"
denotes number of data items

"dataIndex"
represents each dataset. It corresponds to all the other files regarding datasets.

"valuePosi"
indicates the true rank of target bar in this chart

"contrast"
represents the neighborhood condition, e.g., contrast = 100 represents the higheest neighborhood, 0 represents the lowest neighborhood.
