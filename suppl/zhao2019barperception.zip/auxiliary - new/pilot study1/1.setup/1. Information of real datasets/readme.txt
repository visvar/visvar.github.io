"[D]Dataset Detail.xlsx"
contains the information of datasets, including dataset IDs (the same throughout our work), source website, data item quatities and titles.

"Target chosen.xlsx"
contains the ordinal rank of target bars, true (percentile) ranks of target bars, number of data items, and 4 data characteristics of the datasets (CV, skewness, kurtosis and normality test p-values).
