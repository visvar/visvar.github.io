We split datasets and compare three neighborhoods for each target bar.

"substantial difference" file 
contains thoses targets where neighborhood effect show up (in line with length contrast in PLI).

"reverse" file
contains those targets where we see a reversed pattern from neighborhoo d effect (which is in line with length assimilation in PLI).