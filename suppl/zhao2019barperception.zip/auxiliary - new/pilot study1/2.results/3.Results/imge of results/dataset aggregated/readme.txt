"T25.png", "T50.png", "T75.png"
show difference between neighborhoods.

"Value.png"
shows the influence from target bar rank.

"S25.png", "S50.png", "S75.png"
shows the influence from number of data items.
