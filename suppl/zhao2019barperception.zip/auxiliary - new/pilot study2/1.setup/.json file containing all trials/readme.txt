These 2 files are the stimuli in pilot study 2.

"Block 1.json"
contains simuli for chart N = 13, 18, 32

"Block 2.json"
contains simuli for chart N = 10, 20, 31



Below is the explantion for each feature:

"Index" 
encodes task IDs, containing 9 training trials (-9 to -1) and 126/122 experimental trials for Block1/Block2. 

"dataSource"
contains information for each bar component. 
	"name", "value" and the title and value of bar component 
	"ifTarget" denotes whether this bar is chosen as target.

"barScale"
denotes number of data items

"dataIndex"
represents each dataset. It corresponds to all the other files regarding datasets.

"valuePosi"
indicates the true rank of target bar in this chart

"contrast"
represents the neighborhood condition, e.g., contrast = 100 represents the higheest neighborhood, 0 represents the lowest neighborhood.
